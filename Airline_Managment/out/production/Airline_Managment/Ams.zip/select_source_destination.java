package Ams;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.*;
import javax.swing.*;


public class select_source_destination implements ActionListener {
        JFrame f;
        JLabel l1,l2,l3;
        JButton b,b2;
        Choice ch1, ch2;

        select_source_destination()
        {
            f = new JFrame("Selct source & destination");
            f.setBackground(Color.green);
            f.setLayout(null);

            l1 =  new JLabel();
            l1.setBounds(0,0,500,270);
            l1.setLayout(null);

            ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("Ams/icons/img2.jpeg"));
       Image i1= img.getImage().getScaledInstance(700,370,Image.SCALE_SMOOTH);
       ImageIcon img2 = new ImageIcon(i1);
       l1.setIcon(img2);

       l2 = new JLabel("Source");
       l2.setVisible(true);
       l2.setBounds(40,60,150,30);
       l2.setForeground(Color.white);
       Font f1 = new Font("Arial",Font.BOLD,21);
       l2.setFont(f1);
       l1.add(l2);
       f.add(l1);

            l3 = new JLabel("Destination");
            l3.setVisible(true);
            l3.setBounds(40,120,150,30);
            l3.setForeground(Color.white);
//            Font f1 = new Font("Arial",Font.BOLD,21);
            l3.setFont(f1);
            l1.add(l3);


            ch1 = new Choice();
            ch1.setBounds(240,60,190,25);


//    JFrame jFrame;
//    select_source_destination()
//    {
//
//        jFrame = new JFrame("Source_Destination");
//        jFrame.setLayout(null);
//        jFrame.setSize(600,300);
//        jFrame.setBounds(500,200,600,300);
//
//        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//        JLabel j = new JLabel();
//        j.setBounds(0,0,600,300);
//
//        j.setLayout(null);
//
//        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("Ams/icons/img2.jpeg"));
//        Image i1= img.getImage().getScaledInstance(900,600,Image.SCALE_SMOOTH);
//        ImageIcon img2 = new ImageIcon(i1);
//
//
//        j.setIcon(img2);
//        jFrame.add(j);
//
//
//
//        JLabel jLabel1 = new JLabel("Source");
//        jLabel1.setBounds(100,30,100,100);
//        jLabel1.setFont(new Font("Arial",Font.BOLD,20));
//        j.add(jLabel1);
//
////        JTextField jTextField = new JTextField();
////        jTextField.setBounds(300,67,170,30);
////        j.add(jTextField);
//
//        String cityName[] = {"Kolkaata","Mumbai","Lucknow","Lahore"};
//        JComboBox jComboBox = new JComboBox(cityName);
//        jComboBox.setBounds(300,67,170,30);
//        j.add(jComboBox);
//
//
//        JLabel jLabel2 = new JLabel("Destination");
//        jLabel2.setBounds(100,100,150,100);
//        jLabel2.setFont(new Font("Arial",Font.BOLD,20));
//        j.add(jLabel2);
//
//
////        JTextField jTextField1 = new JTextField();
////        jTextField1.setBounds(300,130,170,30);
////        j.add(jTextField1);
//
//        String cityName2[] = {"Bihar","Delhi","Muradaabad","Punjab"};
//        JComboBox jComboBox1 = new JComboBox(cityName2);
//        jComboBox1.setBounds(300,130,170,30);
//        j.add(jComboBox1);
//
//
//
//
//        JButton jButton = new JButton("Search");
//        jButton.setBounds(150,180,100,30);
//        jButton.setBackground(Color.RED);
//        j.add(jButton);
//
//        JButton jButton1 = new JButton("Close");
//        jButton1.setBounds(300,180,100,30);
//        jButton1.setBackground(Color.RED);
//        j.add(jButton1);
//        jFrame.setVisible(true);


        try{
            ConnectionClass obj = new ConnectionClass();
            String  q = "select distinct destination from bookflight";
            ResultSet rest = obj.sta.executeQuery(q);
            while(rest.next()){

                ch1.add(rest.getString("destination"));
            }
            rest.close();

        }catch(Exception e)
        {
            e.printStackTrace();
        }
            ch2 = new Choice();
            ch2.setBounds(240,120,190,25);

            try{
                ConnectionClass obj = new ConnectionClass();
                String  q = "select distinct destination from bookflight";
                ResultSet rest = obj.sta.executeQuery(q);
                while(rest.next()){

                    ch2.add(rest.getString("destination"));
                }
                rest.close();

            }catch(Exception e)
            {
                e.printStackTrace();
            }

        l1.add(ch1);
        l1.add(ch2);

        ch1.setFont(f1);
        ch2.setFont(f1);

        b = new JButton("Search");
        b.setBounds(140,185,100,30);
        b.addActionListener(this);
        l1.add(b);

        b2=new JButton("Close");
        b2.setBounds(260,185,100,30);
       b2.addActionListener(this);
        b2.setBackground(Color.RED);
        b2.setForeground(Color.WHITE);
        l1.add(b2);


        f.setSize(500,270);
        f.setLocation(450,250);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b2)
        {
            f.setVisible(false);
           new Home_Page().setVisible(true);
        }
        if(ae.getSource()==b)
        {
            f.setVisible(false);
            new flightJourneyDetails(ch1.getSelectedItem(),ch2.getSelectedItem()).setVisible(true);
        }
    }
    public static void main(String args[])
    {
        select_source_destination obj = new select_source_destination();
    }

    public void setVisible(boolean b) {
        setVisible(true);
    }
}
